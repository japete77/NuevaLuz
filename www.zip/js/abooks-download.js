app.service('ABooksDownloader', '$scope', '$ionicPlatform', '$cordovaFile', '$interval', '$rootScope', 
	function($scope, $ionicPlatform, $cordovaFile, $interval, $rootScope) {
	
});